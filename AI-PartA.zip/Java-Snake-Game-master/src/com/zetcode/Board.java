package com.zetcode;
 
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
 
public class Board extends JPanel implements ActionListener {
 
    private final int B_WIDTH = 300;
    private final int B_HEIGHT = 300; 
    private final int DOT_SIZE = 10;
    private final int ALL_DOTS = 900;
    private final int DELAY = 140;
    
    private int dots=4;    
    private final int x[] = new int[dots+1]; 
    private final int y[] = new int[dots+1];
    private final int x2[] = new int[dots+1]; 
    private final int y2[] = new int[dots+1];
    private final int x3[] = new int[dots+1];
    private final int y3[] = new int[dots+1];

    
    private boolean leftDirection = false;
    private boolean rightDirection = true;
    private boolean upDirection = false;
    private boolean downDirection = false;
    private boolean inGame = true;
    private boolean agent1dead=false;
    private boolean agent2dead=false;
    private Timer timer;
    private Image ball;
    private Image head; 
    private Image ball2;
     private Image head2;
     private Image ball3;
     private Image head3;
     private int totalDots=0;
     
     public int heuristicDistance(int q1,int q2 ,int z1,int z2) {
		 
    	 return (int)Math.abs((int)(Math.sqrt(Math.pow(((double)(q1-q2)) ,(double) 2) + Math.pow(((double)(z1-z2)) ,(double) 2)))); 
     }
     
     public boolean noAgentCollosion(int a,int b) { 
    	 
    	 if (b >= B_HEIGHT) {
             return  false;
         }

         if (b < 0) {
        	 return false;
         }

         if (a >= B_WIDTH) {
        	 return false;
         }

         if (a < 0) {
        	 return false;
         }
         
         for(int z=0;z<dots;z++) {
        	 if( ( (a==x2[z] && b== y2[z]) && !agent1dead ) || ( (a==x3[z] && b== y3[z]) && !agent2dead ) )
        		 return false;
         }
    	  
    	 return true;
     } 
     
    public Board() { 
        initBoard();
    }  
     
    private void initBoard() { 

        addKeyListener(new TAdapter());
        setBackground(Color.black); 
        setFocusable(true);

        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));
        loadImages();
        initGame();
    }

    private void loadImages() {
    	
    	
        ImageIcon iid = new ImageIcon("src/resources/blowtill2.png");  
        ball = iid.getImage();

        ImageIcon iih = new ImageIcon("src/resources/blowhead1.png");
        head = iih.getImage();
        
        ImageIcon iid2 = new ImageIcon("src/resources/pinktill2.png"); 
        ball2 = iid2.getImage();

        ImageIcon iih2 = new ImageIcon("src/resources/pinkhead1.png");
        head2 = iih2.getImage();
        
        ImageIcon iid3 = new ImageIcon("src/resources/browntill2.png"); 
        ball3 = iid3.getImage();

        ImageIcon iih3 = new ImageIcon("src/resources/brownhead1.png");
        head3 = iih3.getImage();

    } 
   
    private void initGame() {
        /*
        for (int z = 0; z < dots; z++) { 
            x[z] = 40 - z * 10;
            y[z] =  100 ;
            x2[z] =  240  - z * 10;    
            y2[z] =  200 ;   
            x3[z] =  40  - z * 10;  
            y3[z] =  0 ;
        } 
        */
    	 x[3]=140;
         y[3]=150;
         x[2]=130;
         y[2]=150;
         x[1]=120;
         y[1]=150; 
         x[0]=110;
         y[0]=150;
        
        x3[3]=20;
        y3[3]=270;
        x3[2]=30;
        y3[2]=270;
        x3[1]=40;
        y3[1]=270;
        x3[0]=50;
        y3[0]=270;

        x2[3]=240;  
        y2[3]=270;
        x2[2]=230;
        y2[2]=270;
        x2[1]=220;
        y2[1]=270;
        x2[0]=210;
        y2[0]=270; 
    	//no agent dead
    	/*
        x[0]=150;
        y[0]=150;
        x[1]=150;
        y[1]=140;
        x[2]=140;
        y[2]=140;
        x[3]=140; 
        y[3]=130;
        
        x2[0]=190;  
        y2[0]=180;
        x2[1]=190;
        y2[1]=190;
        x2[2]=200;
        y2[2]=190;
        x2[3]=200;
        y2[3]=200;
        
        x3[0]=100;  
        y3[0]=180;
        x3[1]=100;
        y3[1]=190;
        x3[2]=90;
        y3[2]=190;
        x3[3]=90;
        y3[3]=200;
        */
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        doDrawing(g);
    }
    
    private void doDrawing(Graphics g) {
        
        if (inGame) {
        	for (int z = 0; z < dots; z++) {
                if (z == 0) {
                    g.drawImage(head, x[z], y[z], this);
                   if(!agent1dead) g.drawImage(head2, x2[z], y2[z], this);
                   if(!agent2dead) g.drawImage(head3, x3[z], y3[z], this);
                } else {
                    g.drawImage(ball, x[z], y[z], this);
                    if(!agent1dead) g.drawImage(ball2, x2[z], y2[z], this);
                    if(!agent2dead) g.drawImage(ball3, x3[z], y3[z], this);
                }
            }
            Toolkit.getDefaultToolkit().sync();

        } else {

            gameOver(g);
        }        
    }

    private void gameOver(Graphics g) {
        String msg = "Total Dots of agents: "+totalDots;
        Font small = new Font("Helvetica", Font.BOLD, 14);
        FontMetrics metr = getFontMetrics(small);

        g.setColor(Color.white);
        g.setFont(small);
        g.drawString(msg, (B_WIDTH - metr.stringWidth(msg)) / 2, B_HEIGHT / 2);
    }

    private void firstSnakeMove() { 
    	 int rX,rY = 0,lX,lY,nX,nY,sX,sY,min,min1,min2,snakeX,snakeY,xx1,yy1,xx2,yy2;  
         boolean left,right,north,south;
         right=false;
     	left=false;
     	north=false;
     	south=false;
     	
     	if(x[0]>x[1]) {
        	right=true;
        }
        else if(x[0]<x[1]) {
        	left=true;
        } 
        else if(y[0]>y[1]) {
        		south=true;
            }	
        else if(y[0]<y[1]) {
        		north=true;
            }
     	
    
        for (int z = dots; z > 0; z--) {
            x[z] = x[(z - 1)]; 
            y[z] = y[(z - 1)]; 
            
        }
        int newX = 0,newY=0;
       
    	rX=x[0]+DOT_SIZE;
        rY=y[0];
        lX=x[0]-DOT_SIZE;
        lY=y[0];
        nX=x[0];
        nY=y[0]-DOT_SIZE;
        sX=x[0];
        sY=y[0]+DOT_SIZE;
       
        
        
        min1=heuristicDistance(x[0],x2[0],y[0],y2[0]);
        xx1=x2[0];
        yy1=y2[0];
        for (int z = dots-1; z > 0; z--) {
            if(min1>heuristicDistance(x[0],x2[z],y[0],y2[z])) {
            	min1=heuristicDistance(x[0],x2[z],y[0],y2[z]);
            	xx1=x2[z];
                yy1=y2[z];	
            }
        }
        
        min2=heuristicDistance(x[0],x3[0],y[0],y3[0]);
        xx2=x3[0];
        yy2=y3[0];
        for (int z = dots-1; z > 0; z--) {
            if(min2>heuristicDistance(x[0],x3[z],y[0],y3[z])) {
            	min2=heuristicDistance(x[0],x3[z],y[0],y3[z]);
            	xx2=x3[z];
                yy2=y3[z];	
            }
        }
        
        if(agent1dead) min1=600;
        if(agent2dead) min2=600;  
        if(min1<min2) {
        	snakeX=xx1;
        	snakeY=yy1;
        } 
        else {
        	snakeX=xx2;
        	snakeY=yy2;
        }
 
        if(right) {
            min=heuristicDistance(rX,snakeX,rY,snakeY);
            newX=rX;
            newY=rY;
            
            if(min>heuristicDistance(nX,snakeX,nY,snakeY)) 
            {
            	min=heuristicDistance(nX,snakeX,nY,snakeY);
                newX=nX;
                newY=nY; 
                if(min>heuristicDistance(sX,snakeX,sY,snakeY) )
                	
                {
                	newX=sX;
                    newY=sY;
                }
            
            }
            else if(min>heuristicDistance(sX,snakeX,sY,snakeY) )   	
            {
            	newX=sX;
                newY=sY;
            }
            
        }
        else if(left) {
            min=heuristicDistance(lX,snakeX,lY,snakeY);
            newX=lX;
            newY=lY;
            
            if(min>heuristicDistance(nX,snakeX,nY,snakeY)) 
            {
            	min=heuristicDistance(nX,snakeX,nY,snakeY);
                newX=nX;
                newY=nY; 
                if(min>heuristicDistance(sX,snakeX,sY,snakeY) )
                	
                {
                	newX=sX;
                    newY=sY;
                }
            
            }
            else if(min>heuristicDistance(sX,snakeX,sY,snakeY) )
            	
            {
            	newX=sX;
                newY=sY;
            }
            
        }
        else if(north) {
            min=heuristicDistance(nX,snakeX,nY,snakeY);
            newX=nX;
            newY=nY;
            
            if(min>heuristicDistance(rX,snakeX,rY,snakeY)) 
            {
            	min = heuristicDistance(rX,snakeX,rY,snakeY);
                newX=rX;
                newY=rY; 
                if( min > heuristicDistance(lX,snakeX,lY,snakeY) )
                	
                {
                	newX=lX;
                    newY=lY;
                }
            
            }
            else if(min>heuristicDistance(lX,snakeX,lY,snakeY) )
            	
            {
            	newX=lX;
                newY=lY;
            }
            
            
        }
        else if(south) {
        	min=heuristicDistance(sX,snakeX,sY,snakeY);
            newX=sX;
            newY=sY;
            
            if(min>heuristicDistance(rX,snakeX,rY,snakeY)) 
            {
            	min=heuristicDistance(rX,snakeX,rY,snakeY);
                newX=rX;
                newY=rY; 
                if(min>heuristicDistance(lX,snakeX,lY,snakeY) )
                	
                {
                	newX=lX;
                    newY=lY;
                }
             
            }
            else if(min>heuristicDistance(lX,snakeX,lY,snakeY) )
            	
            {
            	newX=lX;
                newY=lY;
            }
            
        }
        x[0]=newX;
        y[0]=newY; 
    }
    
    private void firstAgentMove() {
    	  int newX = x2[0],newY=y2[0]; 
          int rX,rY = 0,lX,lY,nX,nY,sX,sY,max=600; 
          boolean left,right,north,south;
          right=false;
      	  left=false;
      	  north=false;
      	  south=false;
    	
      	if(x2[0]>x2[1]) {
        	right=true;
        } 
        else if(x2[0]<x2[1]) { 
        	left=true;
        } 
        else if(y2[0]>y2[1]) {
        		south=true;
            }	
        else if(y2[0]<y2[1]) {
        		north=true;
            }
      	
        for (int z = dots-1; z > 0; z--) {
            x2[z] = x2[(z - 1)];
            y2[z] = y2[(z - 1)];  
            
        }
        
    	rX=x2[0]+DOT_SIZE;
        rY=y2[0];
        lX=x2[0]-DOT_SIZE;
        lY=y2[0];
        nX=x2[0];
        nY=y2[0]-DOT_SIZE;
        sX=x2[0];
        sY=y2[0]+DOT_SIZE;

        
 
        if(right) {
        	if(noAgentCollosion(rX,rY))
            max=heuristicDistance(rX,x[0],rY,y[0]);
            newX=rX;
            newY=rY;
            
            if(max < heuristicDistance(nX,x[0],nY,y[0]) && noAgentCollosion(nX,nY)  || (noAgentCollosion(nX,nY) && !noAgentCollosion(rX,rY)) ) 
            {
            	max=heuristicDistance(nX,x[0],nY,y[0]);
                newX=nX;
                newY=nY; 
                if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY) )
                	
                {
                	max=heuristicDistance(sX,x[0],sY,y[0]);
                	newX=sX;
                    newY=sY;
                }
            
            }
            else if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY)  || (noAgentCollosion(sX,sY)  && !noAgentCollosion(nX,nY) && !noAgentCollosion(rX,rY)) )
            	
            {
            	max=heuristicDistance(sX,x[0],sY,y[0]);
            	newX=sX;
                newY=sY;
            }
            
        }
        else if(left) {
            if(noAgentCollosion(lX,lY))
            max=heuristicDistance(lX,x[0],lY,y[0]);
            newX=lX;
            newY=lY;
            
            if( ( max < heuristicDistance(nX,x[0],nY,y[0]) && noAgentCollosion(nX,nY) ) || ( noAgentCollosion(nX,nY) && !(noAgentCollosion(lX,lY)) ) ) 
            {
            	max=heuristicDistance(nX,x[0],nY,y[0]);
                newX=nX;
                newY=nY; 
                if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY) )
                	
                {
                	max=heuristicDistance(sX,x[0],sY,y[0]);
                	newX=sX;
                    newY=sY;
                }
            
            }
            else if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY) || (noAgentCollosion(sX,sY) &&!noAgentCollosion(nX,nY) && !noAgentCollosion(lX,lY)) )
            	
            {
            	max=heuristicDistance(sX,x[0],sY,y[0]);
            	newX=sX;
                newY=sY;
            }
            
        }
        else if(north) {
            if(noAgentCollosion(nX,nY))
            max=heuristicDistance(nX,x[0],nY,y[0]);
            newX=nX;
            newY=nY;
            
            if(max < heuristicDistance(rX,x[0],rY,y[0]) && noAgentCollosion(rX,rY) || (noAgentCollosion(rX,rY) && !noAgentCollosion(nX,nY)) ) 
            {
            	max = heuristicDistance(rX,x[0],rY,y[0]);
                newX=rX;
                newY=rY; 
                if( max < heuristicDistance(lX,x[0],lY,y[0]) && noAgentCollosion(lX,lY))
                	
                {
                	max=heuristicDistance(lX,x[0],lY,y[0]);
                	newX=lX; 
                    newY=lY;
                }
            
            }
            else if( (max<heuristicDistance(lX,x[0],lY,y[0]) &&  noAgentCollosion(lX,lY)) ||( noAgentCollosion(lX,lY) && !noAgentCollosion(rX,rY) && !noAgentCollosion(nX,nY))) 
            	
            {
            	max=heuristicDistance(lX,x[0],lY,y[0]);
            	newX=lX;
                newY=lY;
            }
            
        }
        else if(south) {
            if(noAgentCollosion(sX,sY))
            max=heuristicDistance(sX,x[0],sY,y[0]);
            newX=sX;
            newY=sY;
            
            if(max<heuristicDistance(rX,x[0],rY,y[0]) && noAgentCollosion(rX,rY) || (noAgentCollosion(rX,rY) && !noAgentCollosion(sX,sY)) ) 
            {
            	max=heuristicDistance(rX,x[0],rY,y[0]);
                newX=rX;
                newY=rY; 
                if(max<heuristicDistance(lX,x[0],lY,y[0]) && noAgentCollosion(lX,lY) )
                	
                {
                	max=heuristicDistance(lX,x[0],lY,y[0]);
                	newX=lX;
                    newY=lY;
                }
            
            }
            else if(max<heuristicDistance(lX,x[0],lY,y[0]) && noAgentCollosion(lX,lY) || ( noAgentCollosion(lX,lY) && !noAgentCollosion(rX,rY) && !noAgentCollosion(sX,sY)) )
            	
            {
            	max=heuristicDistance(lX,x[0],lY,y[0]);
            	newX=lX;
                newY=lY;
            }
            
            
        } 
        
        if(max!=600) { 
    	   x2[0]=newX;
           y2[0]=newY;
           ++totalDots;
        }
        else {
        	for (int z = 0; z < dots-1; z++) {
                x2[z] = x2[(z + 1)];
                y2[z] = y2[(z + 1)]; 
                
            }
        	
        }

    }
    
    private void secondAgentMove() {
    	  int newX = x3[0],newY=y3[0];
          int rX,rY = 0,lX,lY,nX,nY,sX,sY,max=600; 
          boolean left,right,north,south;
          right=false;
      	  left=false;
          north=false; 
          south=false;
          
          if(x3[0]>x3[1]) {
          	right=true;
          }
          else if(x3[0]<x3[1]) {
          	left=true;
          } 
          else if(y3[0]>y3[1]) {
          		south=true;
              }	
          else if(y3[0]<y3[1]) {
          		north=true;
              }
    	
        for (int z = dots; z > 0; z--) {
            x3[z] = x3[(z - 1)];
            y3[z] = y3[(z - 1)]; 
            
        }
      
    	rX=x3[0]+DOT_SIZE;
        rY=y3[0];
    	lX=x3[0]-DOT_SIZE;
        lY=y3[0];
        nX=x3[0];
        nY=y3[0]-DOT_SIZE;
        sX=x3[0];
        sY=y3[0]+DOT_SIZE;
 
        if(right) {
        	
            if(noAgentCollosion(rX,rY))
            max=heuristicDistance(rX,x[0],rY,y[0]);
            newX=rX;
            newY=rY;
            
            if(max < heuristicDistance(nX,x[0],nY,y[0]) && noAgentCollosion(nX,nY)  || (noAgentCollosion(nX,nY) && !noAgentCollosion(rX,rY)) ) 
            {
            	max=heuristicDistance(nX,x[0],nY,y[0]);
                newX=nX;
                newY=nY; 
                if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY) )
                	
                {
                	max=heuristicDistance(sX,x[0],sY,y[0]);
                	newX=sX;
                    newY=sY;
                }
            
            }
            else if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY)  || (noAgentCollosion(sX,sY)  && !noAgentCollosion(nX,nY) && !noAgentCollosion(rX,rY)) )
            	
            {
            	max=heuristicDistance(sX,x[0],sY,y[0]);
            	newX=sX;
                newY=sY;
            }
            
            
        }
        else if(left) {
            if(noAgentCollosion(lX,lY))
            max=heuristicDistance(lX,x[0],lY,y[0]);
            newX=lX;
            newY=lY;
            
            if(max < heuristicDistance(nX,x[0],nY,y[0]) && noAgentCollosion(nX,nY) || (noAgentCollosion(nX,nY) && !noAgentCollosion(lX,lY)) ) 
            {
            	max=heuristicDistance(nX,x[0],nY,y[0]);
                newX=nX;
                newY=nY; 
                if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY) )
                	
                {
                	max=heuristicDistance(sX,x[0],sY,y[0]);
                	newX=sX;
                    newY=sY;
                }
            
            }
            else if(max < heuristicDistance(sX,x[0],sY,y[0]) && noAgentCollosion(sX,sY) || (noAgentCollosion(sX,sY) &&!noAgentCollosion(nX,nY) && !noAgentCollosion(lX,lY)) )
            	
            {
            	max=heuristicDistance(sX,x[0],sY,y[0]);
            	newX=sX;
                newY=sY;
            }
            
            
        }
        else if(north) {
            if(noAgentCollosion(nX,nY))
            max=heuristicDistance(nX,x[0],nY,y[0]);
            newX=nX;
            newY=nY;
            
            if((max < heuristicDistance(rX,x[0],rY,y[0]) && noAgentCollosion(rX,rY)) || (noAgentCollosion(rX,rY) && !noAgentCollosion(nX,nY)) ) 
            {
            	max = heuristicDistance(rX,x[0],rY,y[0]);
                newX=rX;
                newY=rY; 
                if( max < heuristicDistance(lX,x[0],lY,y[0]) && noAgentCollosion(lX,lY))
                	
                {
                	max=heuristicDistance(lX,x[0],lY,y[0]);
                	newX=lX; 
                    newY=lY;
                }
            
            }
            
            else if( (max < heuristicDistance(lX,x[0],lY,y[0]) &&  noAgentCollosion(lX,lY)) ||( noAgentCollosion(lX,lY) && !noAgentCollosion(rX,rY) && !noAgentCollosion(nX,nY))) 
            	
            {
            	max=heuristicDistance(lX,x[0],lY,y[0]);
            	newX=lX;
                newY=lY;
            }
            
            
        }
        else if(south) {
            if(noAgentCollosion(sX,sY))
            max=heuristicDistance(sX,x[0],sY,y[0]);
            newX=sX;
            newY=sY;
            
            if(max < heuristicDistance(rX,x[0],rY,y[0]) && noAgentCollosion(rX,rY) || (noAgentCollosion(rX,rY) && !noAgentCollosion(sX,sY)) ) 
            {
            	max=heuristicDistance(rX,x[0],rY,y[0]);
                newX=rX;
                newY=rY; 
                if(max < heuristicDistance(lX,x[0],lY,y[0]) && noAgentCollosion(lX,lY) )
                	
                {
                	max=heuristicDistance(lX,x[0],lY,y[0]);
                	newX=lX;
                    newY=lY;
                }
            
            }
            else if(max < heuristicDistance(lX,x[0],lY,y[0]) && noAgentCollosion(lX,lY) || ( noAgentCollosion(lX,lY) && !noAgentCollosion(rX,rY) && !noAgentCollosion(sX,sY)) )
            	
            {
            	max=heuristicDistance(lX,x[0],lY,y[0]);
            	newX=lX;
                newY=lY;
            }
            
            
        }
        if(max!=600) {
    	   x3[0]=newX;
           y3[0]=newY; 
       	++totalDots;
        }
        else {
        	for (int z = 0; z < dots; z++) {
                x3[z] = x3[(z + 1)]; 
                y3[z] = y3[(z + 1)]; 
                
            }
        }
      
    }

    private void checkCollisionSnakeAgent() {

        for (int z = dots-1; z > 0; z--) {

            if ((z > 4) && (x[0] == x[z]) && (y[0] == y[z])) {
                inGame = false;
            }
        }
        
        if(!agent1dead) {
        for (int z = 0; z < dots ; z++) {

            if ((x[0] == x2[z]) && (y[0] == y2[z])) { 
            	agent1dead = true;
            }
        }
       }
        if(!agent2dead) {
        for (int z = 0; z < dots ; z++) {

            if ((x[0] == x3[z]) && (y[0] == y3[z])) { 
            	agent2dead = true; 
            }
        }
       }        
        
        if(agent1dead && agent2dead) inGame = false;
        
        if (y[0] >= B_HEIGHT) {
            inGame = false;
        }

        if (y[0] < 0) {
            inGame = false;
        }

        if (x[0] >= B_WIDTH) {
            inGame = false;
        }

        if (x[0] < 0) {
            inGame = false;
        }
        
        if(upDirection == true) inGame=false ;
        
        if (!inGame) {
            timer.stop();
        }
    } 
    
    @Override
    public void actionPerformed(ActionEvent e) {

        if (inGame) {
           firstSnakeMove(); 
           if(!agent1dead) firstAgentMove(); 
           if(!agent2dead) secondAgentMove();
           repaint(); 
           checkCollisionSnakeAgent();  
        }
        repaint(); 
    }

    private class TAdapter extends KeyAdapter {

        @Override 
        public void keyPressed(KeyEvent e) {

            int key = e.getKeyCode();

            if ((key == KeyEvent.VK_LEFT) && (!rightDirection)) {
                leftDirection = true;
                upDirection = false;
                downDirection = false;
            }

            if ((key == KeyEvent.VK_RIGHT) && (!leftDirection)) {
                rightDirection = true;
                upDirection = false;
                downDirection = false;
            }

            if ((key == KeyEvent.VK_UP) && (!downDirection)) {
                upDirection = true;
                rightDirection = false;
                leftDirection = false;
            }

            if ((key == KeyEvent.VK_DOWN) && (!upDirection)) {
                downDirection = true;
                rightDirection = false;
                leftDirection = false;
            }
        }
    }
}